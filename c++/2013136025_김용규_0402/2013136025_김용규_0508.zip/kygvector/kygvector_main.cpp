#include "kygvetor_class.h"

void main(){
	
	Vector a(5), b(5), c;

	a.setRandom();
	b.setRandom();
//	a.read("VectorA");
//	b.read("VectorB");
	c.add(a,b);

	a.print("  A:");
	b.print("  B:");
	c.print(" C.add(A,B):");



}