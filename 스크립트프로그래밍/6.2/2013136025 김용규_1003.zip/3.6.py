#3.6 (ASCII 코드의 문자 찾기)

a = eval(input("(0부터 127사이의)ASCII코드를 입력하세요 : "))

#chr(a)로 아스키코드값을 문자로 바꿔준다.
print("문자는",chr(a))

